import java.awt.Button;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class SnakeClient extends Frame implements ActionListener, ItemListener {
	Frame frame = new Frame();
	MenuBar menubar;
	Menu menu1;
	Menu menu2;
	MenuItem item1;
	MenuItem item2;
	MenuItem item3;
	Choice choice;
	Button Yes;
	Button No;
	Dialog d;
	
	int GAME_WIDTH = 670;
	int GAME_HEIGHT = 520;
	int x_GameL = 20;
	int y_GameU = 60;
	int x_GameR = 480;
	int y_GameD = 500;
	static int SPEED = 400;
	boolean isStart = false;
	
	snake ss = new snake(this);
	price pc = new price(this);
	Point pt;
	
	Toolkit tk = Toolkit.getDefaultToolkit();
	Image img = tk.getImage(SnakeClient.class.getClassLoader().getResource("img/2.gif"));
	Image bg = tk.getImage(SnakeClient.class.getClassLoader().getResource("img/1.gif"));
	Image bbg = tk.getImage(SnakeClient.class.getClassLoader().getResource("img/11.gif"));
	Image offScreenImage;
	
	public static void main(String[] args) {
		SnakeClient sk = new SnakeClient();
		sk.launchFrame();
	}
	
	public void update(Graphics g) {
		if(offScreenImage == null) {
			offScreenImage = this.createImage(GAME_WIDTH, GAME_HEIGHT);
		}
		Graphics gOffScreen = offScreenImage.getGraphics();
	//	Color c = gOffScreen.getColor();
	//	gOffScreen.setColor(Color.WHITE);
	//	gOffScreen.drawRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
		gOffScreen.drawImage(bg, 0, 0, GAME_WIDTH, GAME_HEIGHT, null);
	//	gOffScreen.drawImage(bbg, x_GameL, y_GameU, GAME_WIDTH - x_GameL, GAME_HEIGHT - y_GameU, null);
	//	gOffScreen.setColor(c);
		paint(gOffScreen);
		g.drawImage(offScreenImage, 0, 0, null);
	}
	
	public void paint(Graphics g) {
		
		Color c = g.getColor();
		g.drawImage(bg, 0, 0, GAME_WIDTH, GAME_HEIGHT, null);
		g.drawImage(bbg, x_GameL, y_GameU, x_GameR - x_GameL, y_GameD - y_GameU, null);
		g.setColor(Color.WHITE);
		Font f = new Font("����", Font.BOLD, 18);
		g.setFont(f);
		g.drawString("Snake's length:" + ss.ls.size(), 490, 100);
		g.drawString("Game speed:" + ss.Game_SPEED, 490, 130);
		g.drawString("Total values:" + ss.values, 490, 160);
		
		if(isStart)	{
			ss.move();
			ss.isGetPrice(pc);
		}
		
		ss.draw(g);
		pc.draw(g);
		
		g.setColor(c);
		
	}
	
	public void launchFrame() {
		menubar = new MenuBar();
		menu1 = new Menu("Game");
		menu2 = new Menu("Setting up");
		item1 = new MenuItem("start");
		item2 = new MenuItem("suspend");
		item3 = new MenuItem("snake speed");
		d = new Dialog(frame, "Snake Speed", true);
		d.setBounds(480, 230, 200, 80);
		d.setLayout(new FlowLayout());
		choice = new Choice();
		choice.add("����  ");
		choice.add("ƫ����  ");
		choice.add("����  ");
		choice.add("ƫ ����  ");
		choice.add("����  ");
		Yes = new Button("Yes");
		Yes.addActionListener(this);
		No = new Button("No");
		No.addActionListener(this);
		d.add(choice);
		d.add(Yes);
		d.add(No);
		menu1.add(item1);
		menu1.add(item2);
		menu2.add(item3);
		menubar.add(menu1);
		menubar.add(menu2);
		this.setMenuBar(menubar);
		this.setBounds(350, 150, GAME_WIDTH, GAME_HEIGHT);
		this.setBackground(Color.GRAY);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		item1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				isStart = true;
				pc.isStart = true;
				pc.time.start();
				pc.isWake = true;
			}
		});
		item2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				isStart = false;
				pc.isStart = false;
				pc.time.stop();
				pc.isWake = false;
			}
		});
		item3.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				d.setVisible(true);
			}
			
		});
		this.addKeyListener(new KeyMonitor());
		this.setTitle("Greedy Snake");
		this.setIconImage(img);
		new Thread(new paintThread()).start();
		
		for(int i=x_GameL; i<120; i+=20) {
			pt = new Point(i, y_GameU);
			ss.ls.add(pt);
		}
		
		this.setVisible(true);
	}
	
	private class KeyMonitor extends KeyAdapter {

		public void keyPressed(KeyEvent e) {
			ss.keyPressed(e);
		}
		
	}

	public class paintThread implements Runnable {

		public void run() {
			while(true) {
				repaint();
				try {
					Thread.sleep(SPEED);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == Yes) {
			d.setVisible(false);
		}
		else if(e.getSource() == No) {
			d.setVisible(false);
		}
	}

	public void itemStateChanged(ItemEvent e) {
		String speed = choice.getSelectedItem();
		switch(speed) {
		case "����  ":
			break;
		case "ƫ����  ":
			break;
		case "����  ":
			break;
		case "ƫ ����  ":
			break;
		case "����  ":
			break;
		}
	}

}
