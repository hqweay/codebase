import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.management.timer.TimerNotification;
import javax.swing.Timer;


public class price implements ActionListener {
	int x, y;
	int m, n;
	int tt = (int)(Math.random()*10000);
	int fixTime = 5;
	int t = tt > fixTime ? tt : fixTime;
	boolean flag = true;
	boolean isDraw = false;
	boolean isWake = false;
	boolean isStart = false;
	Timer time = new Timer(t, this);
	SnakeClient sc;
	
	
	public price(SnakeClient sc) {
		this.sc = sc;
	}
	
	public void draw(Graphics g){
		if(isStart) {
		
			if(flag) {
				do {
					m = (int)(Math.random()*332)/10*20;
					n = (int)(Math.random()*375)/20*20;
					x = m;
					y = n;
				}while(x < sc.x_GameL || x + 20 > sc.x_GameR || y < sc.y_GameU || y + 20 > sc.y_GameD);
			}
			
			if(isDraw) {
				Color c = g.getColor();
				g.setColor(Color.BLUE);
				g.fillRect(x, y, 20, 20);
				g.setColor(c);
			}
			
		}
		
	}
	
	public void actionPerformed(ActionEvent e) {
		System.out.println("actionPerformed");
		if(flag == false) {
			isDraw = false;
			flag = true;
		}
		else {
			isDraw = true;
			flag = false;
		}
	}
	
}