import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;


public class snake {
	int x, y;
	int SIZE = 20;
	int Game_SPEED = 20;
	int XSPEED = Game_SPEED;
	int YSPEED = Game_SPEED;
	static int values = 0;
	boolean isUp = false;
	boolean isLeft = false;
	boolean isVertical = true;
	boolean x_dir = true;
	boolean y_dir = false;
	boolean isWin = false;
	boolean isLose = false;
	boolean isEat = false;
	boolean isGot = false;
	static List<Point> ls = new ArrayList<Point>();
	public static int step = 0;
	SnakeClient sc;
	
	public snake(SnakeClient sc) {
		this.sc = sc;
	}
	
	public void draw(Graphics g) {
		Color c = g.getColor();
		g.setColor(Color.RED);

		if(isLose){
			Font f = new Font("Times New Roman", Font.BOLD, 40);
			g.setFont(f);
			g.drawString("   Loser!", 150, 240);
			return;
		}
		else if(isEat) {
			Font f = new Font("Times New Roman", Font.BOLD, 40);
			g.setFont(f);
			g.drawString("You eat yourself!", 100, 240);
			return;
		}
		
		for(int i=0; i<ls.size(); ++i) {
			g.fillRect(ls.get(i).x, ls.get(i).y, SIZE, SIZE);
		}
		
		g.setColor(c);

	}
	
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		switch(key) {
		case KeyEvent.VK_UP:
			if(isUp == true) {
				return;
			}
			isLeft = false;
			isVertical = true;
			YSPEED = -20;
			x_dir = false;
			y_dir = true;
			break;
		case KeyEvent.VK_DOWN:
			if(isUp == true) {
				return;
			}
			isLeft = false;
			isVertical = true;
			YSPEED = 20;
			x_dir = false;
			y_dir = true;
			break;
		case KeyEvent.VK_LEFT:
			if(isLeft == true) {
				return;
			}
			isUp = false;
			isVertical = false;
			XSPEED = -20;
			y_dir = false;
			x_dir = true;
			break;
		case KeyEvent.VK_RIGHT:
			if(isLeft == true) {
				return;
			}
			isUp = false;
			isVertical = false;
			XSPEED = 20;
			y_dir = false;
			x_dir = true;
			break;
		}
		
	}
	
	public void move() {
		
		if(isGot) {
			
			Point p = new Point(ls.get(ls.size()-1));
			Point t = new Point(p);
			ls.add(t);
			if(x_dir) {
				ls.get(ls.size()-1).x += XSPEED;
				if(isLeft == false) {
					isLeft = true;
				}
			}
			else {
				ls.get(ls.size()-1).y += YSPEED;
				if(isUp == false) {
					isUp = true;
				}
			}
			
			isGot = false;
		}
		else {
			
			for(int i = 1; i<ls.size(); ++i) {
				ls.get(i-1).x = ls.get(i).x;
				ls.get(i-1).y = ls.get(i).y;
			}
			
			if(x_dir) {
				
				ls.get(ls.size()-1).x += XSPEED;
				if(isLeft == false) {
					isLeft = true;
				}
				
			}
			else{
				ls.get(ls.size()-1).y += YSPEED;
				
				if(isUp == false) {
					isUp = true;
				}
			}
			
		}
		test();
	}
	
	public boolean isGetPrice(price pc) {
		if(pc.isDraw && ls.get(ls.size()-1).x == pc.x && ls.get(ls.size()-1).y == pc.y) {
			isGot = true;
			pc.isDraw = false;
			values ++ ;
			if(values%5 == 0 && (sc.SPEED - 100 >= 50)) {
				Game_SPEED += 10;
				sc.SPEED -= 100;
			}
			
			return true;
		}
		
		return false;
	}
	
	public boolean test() {
		
		if(ls.get(ls.size()-1).x + XSPEED > sc.x_GameR || ls.get(ls.size()-1).y + YSPEED > sc.y_GameD || ls.get(ls.size()-1).x < sc.x_GameL || ls.get(ls.size()-1).y < sc.y_GameU) {     
			isLose = true;
			sc.isStart = false;
			return true;
		}
		
		for(int j=0; j<ls.size()-1; ++j) {
			if(ls.get(ls.size()-1).x == ls.get(j).x && ls.get(ls.size()-1).y == ls.get(j).y) {
				isEat = true;
				sc.isStart = false;
				return true;
			}
		}
		
		return false;
	}
	
	
}
	
