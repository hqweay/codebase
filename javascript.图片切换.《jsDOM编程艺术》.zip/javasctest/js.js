function showImage(whichpic) {
    var source = whichpic.getAttribute("href");
    var place = document.getElementById("placeholder");
    place.setAttribute("src", source);

    var text = whichpic.getAttribute("title");
    var description = document.getElementById("description");

    description.firstChild.nodeValue = text;
}

function prepareGallery() {
    if (!document.getElementById) return false;
    if (!document.getElementsByTagName) return false;

    var gallery = document.getElementById("gallery");
    var links = gallery.getElementsByTagName("a");
    for (var i = 0; i < links.length; i++) {
        links[i].onclick = function () {
            showImage(this);
            return false;
        }
    }
}

function startHtml() {
    var textDescription = document.createElement("p");
    textDescription.setAttribute("id", "description");
    var text = document.createTextNode("choose a pic");
    textDescription.appendChild(text);
    var imgPlaceholder = document.createElement("img");
    imgPlaceholder.setAttribute("id", "placeholder");
    imgPlaceholder.setAttribute("src", "image4.jpg");
    imgPlaceholder.setAttribute("alt", "my image");

    document.body.appendChild(textDescription);
    document.body.appendChild(imgPlaceholder);
}


addLoadEvent(startHtml);
addLoadEvent(prepareGallery);

function addLoadEvent(func) {
    var oldonload = window.onload;
    if (typeof window.onload != 'function') {
        window.onload = func;
    } else {
        window.onload = function () {
            oldonload();
            func();
        }
    }
}
